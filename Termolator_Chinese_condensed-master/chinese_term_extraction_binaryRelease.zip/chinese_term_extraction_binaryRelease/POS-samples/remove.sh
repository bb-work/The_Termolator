#!/bin/bash

# Usage: bash remove.sh

# removes <..> whatever is in the arrow brackets, the html

#back up file with -e extenstion
find sampleRDG -type f | xargs sed -i -e 's/\<.*\>//g'

find sampleBackground -type f | xargs sed -i -e 's/\<.*\>//g'

#clean up backup if you've checked everything is right
rm sampleRDG/*.xml-e

rm sampleBackground/*.xml-e