# convert from POS to CONLL format for fore and background folders
#./pos2conll.py POS_OUTPUT_DIR CONLL_OUTPUT_DIR CONLL_FILE_LIST
#POS_OUTPUT_DIR is the output directory of the Brandeis tagger 
#CONLL_OUTPUT_DIR is the directory that we save the output files in CoNLL format
#CONLL_FILE_LIST is an output file: pos2conll.py will create a list of files it has written to CONLL_OUTPUT_DIR in CONLL_FILE_LIST


#./pos2conll.py POS-samples/sampleRDG CoNLL-samples/sampleRDG sample.pos.filelist

#./pos2conll.py POS-samples/sampleBackground CoNLL-samples/sampleBackground sample.neg.filelist


./pos2conll.py test_tagged/foreground CoNLL_test/sampleRDG sample.pos.filelist

./pos2conll.py test_tagged/background CoNLL_test/sampleBackground sample.neg.filelist

# run chinese termolator, find output file as sample.output

./run_cn.sh sample.pos.filelist sample.neg.filelist inputfromChinese.output
