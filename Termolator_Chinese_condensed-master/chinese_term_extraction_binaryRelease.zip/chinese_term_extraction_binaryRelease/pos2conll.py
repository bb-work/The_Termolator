#!/usr/bin/env python3
import sys
from os import listdir, makedirs
from os.path import isfile, join
class ConllUnit():
	def __init__(self, token):
		parts = token.strip().split('_')
		if len(parts) != 2:
			self.token = '__UNK__'
			self.lemma = '__UNK__'
			self.pos   = '__UNK__'
			self.chunk = '__UNK__'
		else:
			self.token = parts[0]
			self.lemma = parts[0]
			self.pos   = parts[1]
			self.chunk = parts[1]

	def __str__(self):
		if self.token == '__UNK__':
			return ''
		else:
			return '%s\t%s\t%s\t%s\n' % (self.token, self.lemma, self.pos, self.chunk)

	def inNP(self):
		result = self.pos == 'NN' or self.pos == 'JJ'
		return result

def convert(f, outf):
	out = open(outf, 'w')
	for l in open(f).readlines():
		units = list(map(lambda x: ConllUnit(x), l.strip().split()))
		i = len(units) - 1
		isNP = False
		while i > -1:
			u = units[i]
			u.chunk = 'O'
			if (u.pos == 'JJ' and isNP):
				if (i > 0 and units[i-1].inNP()):
					u.chunk = 'I-NP'
				else:
					u.chunk = 'B-NP'
					isNP = False
			if (u.pos == 'NN'):
				isNP = True
				if (i > 0 and units[i-1].inNP()):
					u.chunk = 'I-NP'
				else:
					u.chunk = 'B-NP'
					isNP = False
			i -= 1
		for u in units:
			out.write(str(u))
		out.write('\n')

def main(args):
	try:
		input_dir  = args[0]
		output_dir = args[1]
		output_filelist = args[2]
	except:
		print('pos2conll.py input_dir output_dir output_filelist', file=sys.stderr)
		sys.exit(-1)
	makedirs(output_dir)
	out = open(output_filelist, 'w')
	for f in listdir(input_dir):
		if isfile(join(input_dir,f)):
			input_file = join(input_dir, f)
			output_file = join(output_dir, f)
			convert(input_file, output_file)
			out.write(output_file + '\n')

if __name__ == '__main__':
	main(sys.argv[1:])