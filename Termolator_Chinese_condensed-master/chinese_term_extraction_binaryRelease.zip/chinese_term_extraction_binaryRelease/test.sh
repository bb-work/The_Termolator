# script to run termolator for testng while condensing it of irrelevant files

# run chinese termolator, find output file as sample.output

./run_cn.sh sample.pos.filelist sample.neg.filelist sample_test.output

# see if there's any diff in produced output compared to what it was supposed to
diff sample_test.output sample.output

