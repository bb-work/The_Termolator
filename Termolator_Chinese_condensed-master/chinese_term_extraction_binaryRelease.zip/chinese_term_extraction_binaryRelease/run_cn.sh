TERMSYS_ROOT=.
RDG_FILE_LIST=$1
NEG_FILE_LIST=$2
OUTPUT_FILE=$3
java -cp "FuseJet.jar:jet-all.jar" -Xmx8g FuseJet.Terminology.ChineseTerminologyExtractor ${TERMSYS_ROOT}/FuseJet-TermExtraction_NewCN.properties ${RDG_FILE_LIST} ${NEG_FILE_LIST} > ${OUTPUT_FILE}

